<?php
   header('Location: login/index.php');

   // header('Location: larvel/index.html');

?>