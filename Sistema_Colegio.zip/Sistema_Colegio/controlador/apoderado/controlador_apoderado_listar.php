
<?php
   // Dentro de tu controlador PHP
require '../../modelo/modelo_apoderado.php';
// controlador_apoderado_listar.php
$MU = new Apoderado();
$consulta = $MU->listar_apoderado();

// Verifica si la consulta devuelve resultados
if ($consulta) {
    echo json_encode($consulta);  // Asegúrate de que esto sea un JSON válido
} else {
    echo json_encode([
        "data" => []  // Si no hay resultados, devolvemos un array vacío
    ]);
}



?>
