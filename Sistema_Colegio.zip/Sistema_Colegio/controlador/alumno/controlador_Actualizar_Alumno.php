<?php
    require '../../modelo/modelo_alumnos.php';
    $MU = new Alumno();

     header('Content-Type: application/json');
    $data = json_decode(file_get_contents("php://input"), true);
    if (isset($data['student'])) {}
    $student = $data['student'];

   // Acceder a los datos del estudiante
    $idalumno = $student['idalumnoedit'];
    $apellp = $student['apellp'];
    $nombre = $student['nomb'];
    $fechaN = $student['fechaN'];
    $dni = $student['dni'];
    $telf = $student['telf'];
    $codi = $student['codi'];
    $sexo = $student['sex'];
    $direccion = $student['direccion'];

    // Datos de los padres
    $nom_pade = $student['nom_pade'];
    $apell_pade = $student['apell_pade'];
    $dni_pade = $student['dni_pade'];
    $nom_madre = $student['nom_madre'];
    $apell_madre = $student['apell_madre'];
    $dni_madre = $student['dni_madre'];
    // Datos escolares
    $nom_cole = $student['nom_cole'];
    $nom_direc = $student['nom_direc'];
    $cole_codig = $student['cole_codig'];

    $mail = $student['mail'];
    $country = $student['country'];
    $age = !empty($student['age']) ? $student['age'] : 0;
    $province = $student['province'];
    $municipality = $student['municipality'];
    $others = $student['others'];

     $planeStudy = $student['planeStudy'];
    $especiality = $student['especiality'];
    // Datos de procedencia
    $procedente = $student['procedente']; 

  // $Existe= $MU->Verificar_Existencia($apellp,$nombre,$dni,$codi);
    //if($Existe==0){

       $MU->Actualizar_New_Alumno($idalumno,$apellp,$nombre,$fechaN, $dni,$telf,$codi,$sexo,$direccion,$mail,$country,$age,$province,$municipality,$others,$planeStudy,$especiality);

     $consulta = $MU->Actualizar_New_Apoderados($idalumno,$nom_pade,$apell_pade,$dni_pade,$nom_madre,$apell_madre,$dni_madre,$nom_cole, $nom_direc,$cole_codig);

       if(!empty($procedente)) {
            foreach ($procedente as $item) {
                if ($item['id'] === null) {
                     $MU->registrarNuevoProcedente($item['id'],$idalumno,$item['nombre'],$item['localidad'],$item['ep_data'],$item['yeard']);
                } else {
                   
                     $MU-> actualizarProcedente($item['id'],$idalumno,$item['nombre'],$item['localidad'],$item['ep_data'],$item['yeard']);
                }
            }

          }
   
    echo  $consulta;
//}else{
   // echo 100;
//}

?>