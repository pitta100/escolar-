
<?php
    class Apoderado{
        private $conexion;
        function __construct(){
            require_once 'modelo_conexion.php';
            $this->conexion = new conexion();
            $this->conexion->conectar();
        }

   /*
   function Extraer_contracena($usu_id){
        $sql = "SELECT usu_id,usu_contrasena FROM usuarios WHERE usu_id='$usu_id'";
     $arreglo = array();
     if ($consulta = $this->conexion->conexion->query($sql)) {
         while ($consulta_VU = mysqli_fetch_array($consulta)) {
                   
                 $arreglo[] = $consulta_VU;
                    
         }
         return $arreglo;
         $this->conexion->cerrar();
    }
 }
*/
 function listar_apoderado(){
 $sql=  " select idApoderado,paderNombre, PadreApellidos, padreDni, madreNombres, madreApellidos, madreDni from apoderados ";

            $arreglo = array();
            if ($consulta = $this->conexion->conexion->query($sql)) {
                while ($consulta_VU = mysqli_fetch_assoc($consulta)) {
                    $arreglo["data"][]=$consulta_VU;
                }
                return $arreglo;
                $this->conexion->cerrar();
            }
}




}
?>